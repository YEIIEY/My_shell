echo " Hello from script!"
echo " Current Directory: $(pwd)"
ls -l
